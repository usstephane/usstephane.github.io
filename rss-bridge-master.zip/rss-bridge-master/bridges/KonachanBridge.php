<?php
require_once('MoebooruBridge.php');

class KonachanBridge extends MoebooruBridge {

	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Konachan';
	const URI = 'https://konachan.com/';
	const DESCRIPTION = 'Returns images from given page';

}
